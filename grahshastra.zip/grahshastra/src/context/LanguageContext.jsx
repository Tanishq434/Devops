import React, { createContext, useContext, useState } from 'react';

const LanguageContext = createContext();

export const translations = {
  en: {
    // Navbar
    home: 'Home',
    horoscope: 'Horoscope',
    kundli: 'Kundli',
    zodiac: 'Zodiac',
    compatibility: 'Compatibility',
    panchang: 'Panchang',
    // Hero
    tagline: 'Discover Your Cosmic Blueprint',
    heroSub: 'Ancient Vedic wisdom meets modern astrology. Unlock the secrets written in the stars for you.',
    getHoroscope: 'Get Your Horoscope',
    exploreZodiac: 'Explore Zodiac',
    todaysEnergy: "Today's Cosmic Energy",
    energyDesc: 'The planets align in powerful harmony today. Jupiter\'s expansion meets Saturn\'s discipline — a perfect day for focused action and spiritual growth.',
    // Sections
    chooseSign: 'Choose Your Sign',
    chooseSignSub: 'Select your zodiac sign to reveal today\'s cosmic guidance',
    dailyHoroscope: 'Daily Horoscope',
    dailyHoroscopeDesc: 'Personalized predictions for love, career, and health — crafted from planetary movements.',
    compatibilityCheck: 'Compatibility',
    compatibilityDesc: 'Discover how the stars align between you and your partner across love, friendship, and marriage.',
    checkNow: 'Check Now',
    readMore: 'Read More',
    // Horoscope page
    selectSign: 'Select Zodiac Sign',
    daily: 'Daily',
    weekly: 'Weekly',
    monthly: 'Monthly',
    love: 'Love',
    career: 'Career',
    health: 'Health',
    luckyNumber: 'Lucky Number',
    luckyColor: 'Lucky Color',
    mood: 'Mood',
    // Kundli page
    birthChart: 'Birth Chart',
    birthChartSub: 'Enter your birth details to generate your Vedic Kundli',
    yourName: 'Your Name',
    dateOfBirth: 'Date of Birth',
    timeOfBirth: 'Time of Birth',
    placeOfBirth: 'Place of Birth',
    generateKundli: 'Generate Kundli',
    planetaryPositions: 'Planetary Positions',
    yourAscendant: 'Your Ascendant',
    generating: 'Generating your cosmic map...',
    // Zodiac page
    zodiacSigns: 'Zodiac Signs',
    zodiacSub: 'Explore the twelve celestial archetypes and discover your cosmic identity',
    element: 'Element',
    ruling: 'Ruling Planet',
    traits: 'Traits',
    strengths: 'Strengths',
    weaknesses: 'Weaknesses',
    compatible: 'Compatible With',
    // Compatibility page
    compatibilityTitle: 'Compatibility Checker',
    compatibilitySub: 'Discover the cosmic connection between two souls',
    selectFirst: 'Select First Sign',
    selectSecond: 'Select Second Sign',
    checkCompatibility: 'Check Compatibility',
    overall: 'Overall',
    friendship: 'Friendship',
    marriage: 'Marriage',
    // Panchang
    panchangTitle: 'Panchang',
    panchangSub: 'Sacred Hindu calendar with daily auspicious timings',
    tithi: 'Tithi',
    nakshatra: 'Nakshatra',
    yoga: 'Yoga',
    karana: 'Karana',
    auspicious: 'Auspicious Time',
    inauspicious: 'Inauspicious Time',
    // Footer
    about: 'About',
    contact: 'Contact',
    privacy: 'Privacy',
    footerDesc: 'GrahShastra brings ancient Vedic astrological wisdom to the modern seeker.',
  },
  hi: {
    // Navbar
    home: 'होम',
    horoscope: 'राशिफल',
    kundli: 'कुंडली',
    zodiac: 'राशि चक्र',
    compatibility: 'अनुकूलता',
    panchang: 'पंचांग',
    // Hero
    tagline: 'अपना ब्रह्मांडीय मानचित्र खोजें',
    heroSub: 'प्राचीन वैदिक ज्ञान और आधुनिक ज्योतिष का संगम। तारों में लिखे रहस्यों को उजागर करें।',
    getHoroscope: 'राशिफल देखें',
    exploreZodiac: 'राशियाँ देखें',
    todaysEnergy: 'आज की ब्रह्मांडीय ऊर्जा',
    energyDesc: 'आज ग्रह शक्तिशाली सामंजस्य में हैं। बृहस्पति का विस्तार शनि के अनुशासन से मिलता है — केंद्रित कार्य और आध्यात्मिक विकास के लिए एक उत्तम दिन।',
    // Sections
    chooseSign: 'अपनी राशि चुनें',
    chooseSignSub: 'आज का ब्रह्मांडीय मार्गदर्शन पाने के लिए अपनी राशि चुनें',
    dailyHoroscope: 'दैनिक राशिफल',
    dailyHoroscopeDesc: 'प्रेम, करियर और स्वास्थ्य के लिए व्यक्तिगत भविष्यवाणियाँ — ग्रहों की गतिविधियों से बनाई गई।',
    compatibilityCheck: 'अनुकूलता',
    compatibilityDesc: 'जानें कि आपके और आपके साथी के बीच प्रेम, मित्रता और विवाह में तारे कैसे संरेखित होते हैं।',
    checkNow: 'अभी जाँचें',
    readMore: 'और पढ़ें',
    // Horoscope page
    selectSign: 'राशि चुनें',
    daily: 'दैनिक',
    weekly: 'साप्ताहिक',
    monthly: 'मासिक',
    love: 'प्रेम',
    career: 'करियर',
    health: 'स्वास्थ्य',
    luckyNumber: 'भाग्यशाली अंक',
    luckyColor: 'भाग्यशाली रंग',
    mood: 'मनोदशा',
    // Kundli page
    birthChart: 'जन्म कुंडली',
    birthChartSub: 'अपनी वैदिक कुंडली बनाने के लिए जन्म विवरण दर्ज करें',
    yourName: 'आपका नाम',
    dateOfBirth: 'जन्म तिथि',
    timeOfBirth: 'जन्म समय',
    placeOfBirth: 'जन्म स्थान',
    generateKundli: 'कुंडली बनाएं',
    planetaryPositions: 'ग्रहों की स्थिति',
    yourAscendant: 'आपका लग्न',
    generating: 'आपका ब्रह्मांडीय मानचित्र बन रहा है...',
    // Zodiac page
    zodiacSigns: 'राशि चक्र',
    zodiacSub: 'बारह खगोलीय आर्कटाइप्स को एक्सप्लोर करें और अपनी ब्रह्मांडीय पहचान खोजें',
    element: 'तत्व',
    ruling: 'स्वामी ग्रह',
    traits: 'विशेषताएं',
    strengths: 'गुण',
    weaknesses: 'दोष',
    compatible: 'अनुकूल राशियाँ',
    // Compatibility page
    compatibilityTitle: 'अनुकूलता जाँचकर्ता',
    compatibilitySub: 'दो आत्माओं के बीच ब्रह्मांडीय संबंध खोजें',
    selectFirst: 'पहली राशि चुनें',
    selectSecond: 'दूसरी राशि चुनें',
    checkCompatibility: 'अनुकूलता जाँचें',
    overall: 'कुल',
    friendship: 'मित्रता',
    marriage: 'विवाह',
    // Panchang
    panchangTitle: 'पंचांग',
    panchangSub: 'दैनिक शुभ समय के साथ पवित्र हिंदू कैलेंडर',
    tithi: 'तिथि',
    nakshatra: 'नक्षत्र',
    yoga: 'योग',
    karana: 'करण',
    auspicious: 'शुभ समय',
    inauspicious: 'अशुभ समय',
    // Footer
    about: 'हमारे बारे में',
    contact: 'संपर्क',
    privacy: 'गोपनीयता',
    footerDesc: 'GrahShastra आधुनिक साधकों के लिए प्राचीन वैदिक ज्योतिषीय ज्ञान लाता है।',
  }
};

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState('en');
  const t = (key) => translations[lang][key] || translations.en[key] || key;
  const toggleLang = () => setLang(l => l === 'en' ? 'hi' : 'en');
  return (
    <LanguageContext.Provider value={{ lang, t, toggleLang }}>
      {children}
    </LanguageContext.Provider>
  );
}

export const useLang = () => useContext(LanguageContext);
